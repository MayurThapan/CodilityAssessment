$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Scenarios.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: mayurthapan@gmail.com"
    }
  ],
  "line": 5,
  "name": "Following are the assigned Test scenarios",
  "description": "",
  "id": "following-are-the-assigned-test-scenarios",
  "keyword": "Feature",
  "tags": [
    {
      "line": 4,
      "name": "@tag"
    }
  ]
});
formatter.before({
  "duration": 8494305400,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "Users login to application with valid credentials",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 8,
      "value": "#Password is encrypted."
    }
  ],
  "line": 9,
  "name": "User login with credentials: username as  \"mayurthapan@gmail.com\" and password as \"MkFVRzE5NjY\u003d\"",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "mayurthapan@gmail.com",
      "offset": 43
    },
    {
      "val": "MkFVRzE5NjY\u003d",
      "offset": 83
    }
  ],
  "location": "TestSteps.user_login_with_credentials_username_as_and_password_as(String,String)"
});
formatter.result({
  "duration": 3375155900,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Order T-shirt and Verify in Order History",
  "description": "",
  "id": "following-are-the-assigned-test-scenarios;order-t-shirt-and-verify-in-order-history",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 12,
      "name": "@qtTest"
    },
    {
      "line": 12,
      "name": "@Order"
    }
  ]
});
formatter.step({
  "line": 14,
  "name": "User is on myAccount page",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "User select a T-shirt",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "User add T-shirt in cart",
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "Record the T-Shirt details",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "User follows complete Proceed to checkout process",
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "User make the payment and confirm the order",
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "User receieve order confirmation details",
  "keyword": "Then "
});
formatter.step({
  "line": 21,
  "name": "Verify the details on Order History page.",
  "keyword": "And "
});
formatter.match({
  "location": "TestSteps.user_is_on_myAccount_page()"
});
formatter.result({
  "duration": 71729700,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.user_select_a_T_shirt()"
});
formatter.result({
  "duration": 1231579600,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.user_add_T_shirt_in_cart()"
});
formatter.result({
  "duration": 1429909000,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.record_the_T_Shirt_details()"
});
formatter.result({
  "duration": 81741500,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.user_follows_complete_Proceed_to_checkout_process()"
});
formatter.result({
  "duration": 5604190400,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.user_make_the_payment_and_confirm_the_order()"
});
formatter.result({
  "duration": 3080374900,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.user_receieve_order_confirmation_details()"
});
formatter.result({
  "duration": 1855788900,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.verify_the_details_on_Order_History_page()"
});
formatter.result({
  "duration": 165549100,
  "status": "passed"
});
formatter.after({
  "duration": 150300400,
  "status": "passed"
});
formatter.before({
  "duration": 7384945100,
  "status": "passed"
});
formatter.background({
  "line": 7,
  "name": "Users login to application with valid credentials",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 8,
      "value": "#Password is encrypted."
    }
  ],
  "line": 9,
  "name": "User login with credentials: username as  \"mayurthapan@gmail.com\" and password as \"MkFVRzE5NjY\u003d\"",
  "keyword": "Given "
});
formatter.match({
  "arguments": [
    {
      "val": "mayurthapan@gmail.com",
      "offset": 43
    },
    {
      "val": "MkFVRzE5NjY\u003d",
      "offset": 83
    }
  ],
  "location": "TestSteps.user_login_with_credentials_username_as_and_password_as(String,String)"
});
formatter.result({
  "duration": 5222130000,
  "status": "passed"
});
formatter.scenario({
  "line": 25,
  "name": "Update personal Information (First Name) in My Account",
  "description": "",
  "id": "following-are-the-assigned-test-scenarios;update-personal-information-(first-name)-in-my-account",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 24,
      "name": "@qtTest"
    },
    {
      "line": 24,
      "name": "@UpdateFirstName"
    }
  ]
});
formatter.step({
  "line": 26,
  "name": "User is on myAccount page",
  "keyword": "Given "
});
formatter.step({
  "line": 27,
  "name": "User decides to edit his personal information",
  "keyword": "When "
});
formatter.step({
  "line": 28,
  "name": "User update the First name",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 29,
      "value": "#Password is encrypted."
    }
  ],
  "line": 30,
  "name": "User enter the password \"MkFVRzE5NjY\u003d\" and submit",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "User receieve success Information \"Your personal information has been successfully updated.\"",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "User can view the Updated Name dislayed on the top right corner.",
  "keyword": "And "
});
formatter.match({
  "location": "TestSteps.user_is_on_myAccount_page()"
});
formatter.result({
  "duration": 49316900,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.user_decides_to_edit_his_personal_information()"
});
formatter.result({
  "duration": 2137883000,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.user_update_the_First_name()"
});
formatter.result({
  "duration": 113418200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "MkFVRzE5NjY\u003d",
      "offset": 25
    }
  ],
  "location": "TestSteps.user_enter_the_password_and_submit(String)"
});
formatter.result({
  "duration": 807618200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Your personal information has been successfully updated.",
      "offset": 35
    }
  ],
  "location": "TestSteps.user_receieve_success_Information(String)"
});
formatter.result({
  "duration": 34174300,
  "status": "passed"
});
formatter.match({
  "location": "TestSteps.user_can_view_the_Updated_Name_dislayed_on_the_top_right_corner()"
});
formatter.result({
  "duration": 32792700,
  "status": "passed"
});
formatter.after({
  "duration": 120060900,
  "status": "passed"
});
});